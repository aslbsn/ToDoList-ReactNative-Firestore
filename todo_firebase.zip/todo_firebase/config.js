import firebase from 'firebase';

const firebaseConfig = {
 apiKey: "AIzaSyBrPG3Lbhx91QlfxricEqJLEOR1q0N4caU",
  authDomain: "todo-fa54d.firebaseapp.com",
  projectId: "todo-fa54d",
  storageBucket: "todo-fa54d.appspot.com",
  messagingSenderId: "278821495131",
  appId: "1:278821495131:web:5425efa9dfd8320c5dfa7e",
  measurementId: "G-60DR0CCXZG"
};

if(!firebase.apps.length){
  firebase.initializeApp(firebaseConfig);
}

export { firebase };
